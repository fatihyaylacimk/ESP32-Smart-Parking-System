#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>

// RFID
#define SS_PIN     4   // Pin SDA
#define RST_PIN   15  // Pin RST

#define BUZZER_PIN 13 // Buzzer
#define SERVO_PIN  12 // Servo

const int JUMLAH_SPACE = 3;
const int JARK_MAKSIMAL = 10; 

const int pinTRIG[JUMLAH_SPACE]      = {14, 32, 2};  
const int pinECHO[JUMLAH_SPACE]      = {27, 33, 35}; 
const int pinLED_MERAH[JUMLAH_SPACE] = {25, 16, 5}; 
const int pinLED_HIJAU[JUMLAH_SPACE] = {26, 17, 0}; 

LiquidCrystal_I2C lcd(0x27, 16, 2);
MFRC522 mfrc522(SS_PIN, RST_PIN);
Servo gerbangServo;

void setup() {
  Serial.begin(115200);
  SPI.begin();
  mfrc522.PCD_Init();
  
  // Setup Servo & Buzzer
  gerbangServo.attach(SERVO_PIN);
  gerbangServo.write(0); 
  pinMode(BUZZER_PIN, OUTPUT);
  
  for(int i = 0; i < JUMLAH_SPACE; i++) {
    pinMode(pinTRIG[i], OUTPUT);
    pinMode(pinECHO[i], INPUT);
    pinMode(pinLED_MERAH[i], OUTPUT);
    pinMode(pinLED_HIJAU[i], OUTPUT);
  }
  
  // Setup LCD
  lcd.init();
  lcd.backlight();
  lcd.clear();
}

void loop() {
  int spaceTerisi = 0;
  int spaceKosong = 0;

  // 1. Cek Status Semua Space Parkir
  for(int i = 0; i < JUMLAH_SPACE; i++) {
    long durasi, jarak;
    
    // Trigger Sensor Ultrasonic
    digitalWrite(pinTRIG[i], LOW);
    delayMicroseconds(2);
    digitalWrite(pinTRIG[i], HIGH);
    delayMicroseconds(10);
    digitalWrite(pinTRIG[i], LOW);
    
    durasi = pulseIn(pinECHO[i], HIGH);
    jarak = durasi * 0.034 / 2; // Menghitung jarak dalam cm
    
    // Logika Deteksi Mobil (Jika jarak kurang dari batas, berarti ada mobil)
    if (jarak > 0 && jarak <= JARK_MAKSIMAL) { 
      digitalWrite(pinLED_MERAH[i], HIGH);
      digitalWrite(pinLED_HIJAU[i], LOW);
      spaceTerisi++;
    } else {
      digitalWrite(pinLED_MERAH[i], LOW);
      digitalWrite(pinLED_HIJAU[i], HIGH);
      spaceKosong++;
    }
    delay(50); // Delay kecil antar sensor agar tidak saling mengganggu suara ultrasonik
  }

  // 2. Tampilkan Info Space di LCD
  lcd.setCursor(0, 0);
  lcd.print("Kosong: " + String(spaceKosong) + "      ");
  lcd.setCursor(0, 1);
  lcd.print("Terisi: " + String(spaceTerisi) + "      ");

  // 3. Cek Tap RFID Reader
  // Jika tidak ada kartu baru didekatkan, lewati fungsi dibawah
  if ( ! mfrc522.PICC_IsNewCardPresent()) {
    return;
  }
  // Jika kartu tidak terbaca, lewati fungsi dibawah
  if ( ! mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  // JIKA BERHASIL TAP RFID:
  // Tampilan LCD saat gerbang terbuka
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("   WELCOME!   ");
  lcd.setCursor(0, 1);
  lcd.print("Gerbang Terbuka");

  // Bunyikan Buzzer
  digitalWrite(BUZZER_PIN, HIGH);
  delay(200);
  digitalWrite(BUZZER_PIN, LOW);

  // Buka Servo Gerbang (90 derajat)
  gerbangServo.write(90);
  
  // Tahan gerbang terbuka selama 5 detik agar mobil bisa masuk
  delay(5000); 
  
  // Tutup kembali gerbang
  gerbangServo.write(0);
  lcd.clear();
  
  // Selesai membaca kartu aktif
  mfrc522.PICC_HaltA();
}